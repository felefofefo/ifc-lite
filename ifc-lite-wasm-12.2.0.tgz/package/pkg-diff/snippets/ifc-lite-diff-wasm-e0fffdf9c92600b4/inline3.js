
const scApplyIntrinsic = Reflect.apply;
export function scGet(value, key) { return value[key]; }
export function scObject(value) { return typeof value === 'object' && value !== null; }
export function scArray(value) { return Array.isArray(value); }
export function scVisit(value, callback) { for (const item of value) if (!callback(item)) break; }
export function scCall(value, name, args) { return value[name](...args); }
export function scContextCall(value, name, context, callback) { return value[name](item => callback(context, item)); }
export function scApply(callee, receiver, args) { return scApplyIntrinsic(callee, receiver, args); }
export function scText(value) { return `${value}`; }
export function scLess(a, b) { return a < b; }
export function scGreater(a, b) { return a > b; }
export function scGreaterEqual(a, b) { return a >= b; }
export function scFinite(value) { return Number.isFinite(value); }
export function scTruthy(value) { return !!value; }
export function scDateNaN(value) { return Number.isNaN(Date.parse(value)); }
export function scError(message) { return new Error(message); }
export function scDefine(value, key, item) { Object.defineProperty(value, key, {value:item, enumerable:true, configurable:true, writable:true}); }
