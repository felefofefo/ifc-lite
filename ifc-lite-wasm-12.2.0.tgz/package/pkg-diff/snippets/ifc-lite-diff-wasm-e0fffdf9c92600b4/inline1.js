
export function diffOwnKeys(value) { return Object.keys(value); }
export function diffIsArray(value) { return Array.isArray(value); }
export function diffAtomJSON(value) { return JSON.stringify(value) ?? 'null'; }
// Only host observation/traversal lives here. Rust returns an atom token,
// null for an array, or sorted object keys, and assembles every composite.
export function diffObserveTree(value, enter, finishArray, finishObject) {
    function visit(value) {
        const plan = enter(value);
        if (typeof plan === 'string') return plan;
        if (plan === null) {
            // Preserve live method lookup, receiver, species, holes, immediate
            // callback results, and template ToString (which rejects Symbols).
            return finishArray(`${value.map(visit).join(',')}`);
        }
        const children = [];
        for (let index = 0; index < plan.length; index++) {
            children[index] = visit(value[plan[index]]);
        }
        return finishObject(plan, children);
    }
    return visit(value);
}
