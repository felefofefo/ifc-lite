
export function diffTransportArray(value) { return Array.isArray(value); }
export function diffTransportLength(value) { return value.length >>> 0; }
export function diffTransportKeys(value) { return Object.keys(value); }
