
export function lineageLess(a, b) { return a < b; }
export function lineageGreater(a, b) { return a > b; }
